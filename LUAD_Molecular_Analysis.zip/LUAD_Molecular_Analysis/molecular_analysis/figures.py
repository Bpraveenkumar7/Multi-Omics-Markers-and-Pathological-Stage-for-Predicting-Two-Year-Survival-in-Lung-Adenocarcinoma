"""Create the two molecular figures from analyze.py output."""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from analyze import OUT, GROWTH, LUNG, COHORTS

TEAL, RUST, INK = "#00766e", "#ad4f2a", "#172d3c"
plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":9,
                     "axes.spines.top":False, "axes.spines.right":False,
                     "axes.labelcolor":INK, "text.color":INK, "axes.edgecolor":"#9facb3",
                     "xtick.color":INK,"ytick.color":INK,"pdf.fonttype":42})


def figure_genes():
    d = pd.read_csv(OUT/"ten_gene_effects.csv")
    fig, axes = plt.subplots(1, 4, sharey=True, figsize=(9,4.5))
    ys = np.array([10,9,8,7,6,4,3,2,1,0])
    for k,(ax,c) in enumerate(zip(axes, COHORTS)):
        df = d[d.cohort.eq(c)].set_index("marker").loc[GROWTH + LUNG]
        ax.axvline(.5, linestyle="--", color="#667783", lw=.9)
        ax.axhline(5, color="#d7dfe3",lw=.6)
        for i, (_,row) in enumerate(df.iterrows()):
            x, y = row.auc_higher_in_deaths, ys[i]
            color = RUST if i < 5 else TEAL
            ax.plot([row.auc_low,row.auc_high], [y,y], color=color,lw=1.4)
            ax.plot(x,y,"o",ms=5,mec=color,mfc=color if row.q_BH < .05 else "white")
        ax.set_xlim(.07,.94)
        ax.set_ylim(-.8,10.9)
        ax.set_xticks([.2,.5,.8],["0.2","0.5","0.8"])
        ax.set_yticks(ys, GROWTH+LUNG,fontstyle="italic")
        ax.tick_params(axis="y", length=0)
        ax.spines["left"].set_visible(False)
        ax.set_title(f"{c}\n{int(df.n_death.iloc[0])} deaths / {int(df.n_death.iloc[0]+df.n_survivor.iloc[0])} patients", fontsize=9.4)
    fig.supxlabel("Probability of higher expression in a death–survivor pair",y=.105,fontsize=10)
    handles=[Line2D([],[],marker="o",ls="",color=INK,label="BH-adjusted p < 0.05"),
             Line2D([],[],marker="o",ls="",color=INK,mfc="white",label="BH-adjusted p ≥ 0.05")]
    fig.legend(handles=handles,loc="lower center",ncol=2,frameon=False,fontsize=8)
    fig.subplots_adjust(left=.12,right=.98,bottom=.22,top=.86,wspace=.13)
    save(fig,"Figure7_gene_effects")


def figure_cpg():
    d=pd.read_csv(OUT/"original_panel_shifts.csv").query("assay == 'CpG'").sort_values("median_difference_CPTAC_minus_TCGA")
    fig, (a,b)=plt.subplots(1,2,sharey=True,figsize=(8.4,6.3))
    y=np.arange(len(d))
    a.axvline(0,color="#9facb3",ls="--",lw=.8)
    a.hlines(y,0,d.median_difference_CPTAC_minus_TCGA,color="#9eb4c2",lw=2.3)
    a.scatter(d.median_difference_CPTAC_minus_TCGA,y,color=INK,s=14,zorder=3)
    a.set(yticks=y,yticklabels=d.marker,xlim=(-.06,.20),xticks=[-.05,0,.05,.10,.15,.20])
    a.set_title("A   Difference in median methylation",loc="left",fontweight="bold",fontsize=10)
    a.set_xlabel("Median β in CPTAC-3 minus median β in TCGA")
    b.axvline(.5,color="#9facb3",ls="--",lw=.8)
    for idx,(_,r) in enumerate(d.iterrows()):
        b.plot([r.TCGA_auc,r["CPTAC-3_auc"]],[idx,idx],color="#adb9c0",lw=1.4)
    b.scatter(d.TCGA_auc,y,color=TEAL,s=18,label="TCGA · 450K",zorder=3)
    b.scatter(d["CPTAC-3_auc"],y,marker="D",color=RUST,s=17,label="CPTAC-3 · EPIC",zorder=3)
    b.set(xlim=(.12,.73),xticks=[.2,.3,.4,.5,.6,.7])
    b.set_title("B   Association with two-year mortality",loc="left",fontweight="bold",fontsize=10)
    b.set_xlabel("Probability of higher β in a death–survivor pair")
    b.legend(loc="lower right",bbox_to_anchor=(1,-.20),ncol=2,fontsize=8,frameon=False)
    for ax in [a,b]:
        ax.tick_params(axis="y",length=0,labelsize=8)
        ax.spines["left"].set_visible(False)
        ax.grid(axis="y",color="#edf0f1",lw=.6)
        ax.set_axisbelow(True)
    fig.subplots_adjust(left=.14,right=.98,bottom=.18,top=.94,wspace=.22)
    save(fig,"Figure8_CpG_transfer")


def save(fig,name):
    for ext in ["png","pdf"]:
        fig.savefig(OUT/f"{name}.{ext}",dpi=420,bbox_inches="tight",pad_inches=.06)
    plt.close(fig)


if __name__=="__main__":
    figure_genes()
    figure_cpg()
