"""Reproduce the transfer forest and characterize the two fixed molecular panels."""
from pathlib import Path
import base64
import hashlib
import io
import json
import re
import sys
import zipfile

import numpy as np
import pandas as pd
from scipy.stats import false_discovery_control, mannwhitneyu

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = HERE / "results"
SEED = 20261125
GROWTH = ["MKI67", "TOP2A", "BIRC5", "CCNB1", "UBE2C"]
LUNG = ["SFTPB", "SFTPC", "SCGB1A1", "NAPSA", "SLC34A2"]
COHORTS = ["TCGA", "CPTAC-3", "GSE72094", "GSE31210"]
EXPECTED = [(267, 89), (85, 10), (320, 78), (201, 11)]


def read_measurements():
    notebook = json.loads((ROOT / "LUAD_external_transfer.ipynb").read_text())
    source = next("".join(c["source"]) for c in notebook["cells"]
                  if c["cell_type"] == "code" and "measurements.csv" in "".join(c["source"]))
    encoded = re.search(r'b64decode\("""(.*?)"""\)', source, re.S).group(1)
    blob = base64.b64decode(encoded)
    assert hashlib.sha256(blob).hexdigest() == "da1eddca50cc2e493a76e2f62bd71f5507e5d9b3ea2a3ae828892eeeb7f49523"
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        data = pd.read_csv(archive.open("measurements.csv"), index_col="patient_id",
                           float_precision="round_trip")
        panel = json.loads(archive.read("shared_panel.json"))
    data = data.loc[data.primary_set].copy()
    assert data.index.is_unique and len(panel) == len(set(panel)) == 32
    assert data[GROWTH + LUNG].notna().all().all()
    assert [(len(g), int(g.death.sum())) for g in [data[data.cohort == c] for c in COHORTS]] == EXPECTED
    return data, panel


def compare(frame, marker, rng):
    """Unadjusted native-scale summaries and outcome contrasts, no missing-value imputation."""
    cases = frame.loc[frame.death.eq(1), marker].dropna().to_numpy()
    controls = frame.loc[frame.death.eq(0), marker].dropna().to_numpy()
    a, b = len(cases), len(controls)
    row = {"cohort": frame.cohort.iloc[0], "marker": marker,
           "n_death": a, "n_survivor": b, "n_missing": len(frame)-a-b}
    for label, vals in [("death", cases), ("survivor", controls)]:
        for stat, q in [("q1", .25), ("median", .5), ("q3", .75)]:
            row[f"{label}_{stat}"] = np.quantile(vals, q) if len(vals) else np.nan
    if not a or not b:
        return row
    wins = (cases[:, None] > controls) + .5 * (cases[:, None] == controls)
    row["auc_higher_in_deaths"] = wins.mean()
    row["p"] = mannwhitneyu(cases, controls, method="asymptotic", alternative="two-sided").pvalue
    # Resample patients within outcome, retaining ties and original group sizes.
    w1 = rng.multinomial(a, np.full(a, 1/a), size=5000)
    w0 = rng.multinomial(b, np.full(b, 1/b), size=5000)
    boot = ((w1 @ wins) * w0).sum(axis=1) / (a*b)
    row["auc_low"], row["auc_high"] = np.quantile(boot, [.025, .975])
    return row


def marker_effects(data, markers, cohorts, rng):
    rows = [compare(data[data.cohort.eq(c)], m, rng) for c in cohorts for m in markers]
    out = pd.DataFrame(rows)
    valid = out.p.notna()
    out.loc[valid, "q_BH"] = false_discovery_control(out.loc[valid, "p"].to_numpy())
    return out


def stage_concordance(data):
    rows = []
    for cohort in COHORTS:
        frame = data[data.cohort.eq(cohort)].dropna(subset=["major"])
        for gene in GROWTH + LUNG:
            score, total = 0., 0
            for _, group in frame.groupby("major"):
                x = group.loc[group.death.eq(1), gene].to_numpy()
                y = group.loc[group.death.eq(0), gene].to_numpy()
                score += ((x[:, None] > y) + .5 * (x[:, None] == y)).sum()
                total += len(x)*len(y)
            rows.append((cohort, gene, len(frame), total, score/total))
    return pd.DataFrame(rows, columns=["cohort", "marker", "n_known_stage", "same_stage_pairs",
                                       "within_stage_auc_higher_in_deaths"])


def coexpression(data):
    rows = []
    for cohort in COHORTS:
        corr = data.loc[data.cohort.eq(cohort), GROWTH + LUNG].corr(method="spearman")
        for i, a in enumerate(corr.columns):
            for b in corr.columns[i+1:]:
                group = ("proliferation" if b in GROWTH else
                         "differentiation" if a in LUNG else "between groups")
                rows.append((cohort, group, a, b, corr.loc[a, b]))
    return pd.DataFrame(rows, columns=["cohort", "group", "gene_1", "gene_2", "spearman_rho"])


def shifts(data, panel, effects):
    rows = []
    for m in panel:
        row = {"marker": m, "assay": "CpG" if m.startswith("cg") else "RNA"}
        for c in COHORTS[:2]:
            x = data.loc[data.cohort.eq(c), m].dropna()
            row[c+"_observed"] = len(x)
            for q, name in [(.25, "q1"), (.5, "median"), (.75, "q3")]:
                row[c+"_"+name] = x.quantile(q)
            row[c+"_auc"] = effects.loc[(effects.cohort == c) & (effects.marker == m),
                                        "auc_higher_in_deaths"].iloc[0]
        row["median_difference_CPTAC_minus_TCGA"] = row["CPTAC-3_median"] - row["TCGA_median"]
        product = (row["TCGA_auc"]-.5)*(row["CPTAC-3_auc"]-.5)
        row["direction"] = ("unavailable" if np.isnan(product) else
                            "concordant" if product > 0 else "opposite" if product < 0 else "neutral")
        rows.append(row)
    return pd.DataFrame(rows)


def refit_benchmark():
    # Import the repository's original fitting code; read its original inputs from the audit archive.
    sys.path.insert(0, str(ROOT / "LUAD_benchmark_audit"))
    import model_eval as me
    with zipfile.ZipFile(ROOT / "LUAD_benchmark_audit.zip") as z:
        patients = pd.read_csv(z.open("patient_matrix.csv"), index_col="patient_id")
        panels = json.loads(z.read("panels.json"))
        archived = pd.read_csv(z.open("external_predictions.csv"), index_col="patient_id")
        reference = pd.read_csv(z.open("external85_auc_intervals.csv"), index_col=0)
    fresh, settings = me.external(patients, panels)
    assert fresh.index.equals(archived.index)
    assert fresh[["death_2y", "in_paper_analysis"]].equals(archived[["death_2y", "in_paper_analysis"]])
    columns = list(settings)
    np.testing.assert_allclose(fresh[columns], archived[columns], rtol=0, atol=1e-10)
    primary = fresh[fresh.in_paper_analysis]
    intervals = me.paired_uncertainty(primary)
    np.testing.assert_allclose(intervals, reference, atol=1e-10)
    result = intervals.loc[columns].join(me.performance(primary)[["Average precision"]])
    result.index.name = "model"
    result.to_csv(OUT / "external85_refit.csv")
    return settings


def main():
    OUT.mkdir(exist_ok=True)
    data, panel = read_measurements()
    rng = np.random.default_rng(SEED)
    genes = marker_effects(data, GROWTH + LUNG, COHORTS, rng)
    genes = genes.merge(stage_concordance(data), on=["cohort", "marker"], validate="one_to_one")
    probes = marker_effects(data, panel, COHORTS[:2], rng)
    genes.to_csv(OUT / "ten_gene_effects.csv", index=False)
    probes.to_csv(OUT / "original_panel_effects.csv", index=False)
    shifts(data, panel, probes).to_csv(OUT / "original_panel_shifts.csv", index=False)
    coexpression(data).to_csv(OUT / "ten_gene_correlations.csv", index=False)
    settings = refit_benchmark()
    (OUT / "refit_parameters.json").write_text(json.dumps(settings, indent=2) + "\n")


if __name__ == "__main__":
    main()
