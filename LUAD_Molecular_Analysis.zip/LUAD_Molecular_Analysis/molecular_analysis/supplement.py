"""Assemble manuscript Tables S1–S9, reusing the unchanged external-transfer notebook."""
from pathlib import Path
from tempfile import TemporaryDirectory
import os
import sys
import json
import zipfile
import numpy as np
import pandas as pd
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from analyze import ROOT, OUT, GROWTH, LUNG


def original_results():
    notebook = json.loads((ROOT/"LUAD_external_transfer.ipynb").read_text())
    namespace = {}
    # The published notebook writes files in its current working directory.
    old_dir = Path.cwd()
    with TemporaryDirectory() as scratch:
        try:
            os.chdir(scratch)
            for cell in notebook["cells"]:
                if cell["cell_type"] == "code":
                    exec(compile("".join(cell["source"]), "LUAD_external_transfer.ipynb", "exec"), namespace)
        finally:
            os.chdir(old_dir)
    return namespace


def tables():
    n = original_results()
    pairs = []
    for label, f in n["predictions"].groupby("test",sort=False):
        y = f.death.astype(bool)
        stage = f[n["STAGE"]]
        same = stage[y].to_numpy()[:,None] == stage[~y].to_numpy()
        values = []
        for model in [n["CLIN"], n["PRIMARY"]]:
            x = f[model]
            delta = x[y].to_numpy()[:,None] - x[~y].to_numpy()
            values.append(((delta>0) + .5*(delta==0))[same].sum())
        pairs.append([label, same.size, same.sum(), *values, values[1]-values[0]])
    with zipfile.ZipFile(ROOT/"LUAD_benchmark_audit.zip") as z:
        repeats = pd.read_csv(z.open("repeat_auc.csv"))
    markers = pd.DataFrame([("Published panel", "CpG" if m.startswith("cg") else "RNA", m) for m in n["panel"]]
                           +[("RNA score", "Proliferation", m) for m in GROWTH]
                           +[("RNA score", "Differentiation", m) for m in LUNG],
                           columns=["panel","component","marker"])
    return {"S1 CV repetitions":repeats, "S2 External models":n["result"],
            "S3 Same stage":pd.DataFrame(pairs,columns=["cohort","all_pairs","same_stage_pairs","clinical_points","clinical_rna_points","net_gain"]),
            "S4 Marker definitions":markers, "S5 Ten genes":pd.read_csv(OUT/"ten_gene_effects.csv"),
            "S6 Gene correlations":pd.read_csv(OUT/"ten_gene_correlations.csv"),
            "S7 Original marker effects":pd.read_csv(OUT/"original_panel_effects.csv"),
            "S8 Cohort shifts":pd.read_csv(OUT/"original_panel_shifts.csv"),
            "S9 External refit":pd.read_csv(OUT/"external85_refit.csv")}


def write_book(path):
    frames=tables()
    notes=[
        ("S1","One ROC AUC per pooled outer repetition. The same 85 patients recur across repetitions."),
        ("S2","External scores fixed in TCGA. Bootstrap CIs and comparisons in the baseline follow-up use 10,000 stratified draws."),
        ("S3","Net gain = clinical-plus-RNA points minus clinical points. Original stage-based score uses training-median stage if missing."),
        ("S4","The published 32-marker panel and ten-gene follow-up panel have distinct definitions."),
        ("S5","Observed genes and known outcomes only. Higher-value AUC > 0.5 indicates higher expression in deaths. Ties count half."),
        ("S5, S7","q1 and q3 are the 25th and 75th percentiles. auc_low and auc_high are pointwise 95% intervals from 5,000 stratified patient bootstraps. p is the two-sided asymptotic Mann–Whitney p-value. q_BH adjusts 40 (S5) or 64 (S7) tests."),
        ("S5","Same-stage AUC uses only known-stage pairs sharing the same stage, weighted by pair counts. It is descriptive."),
        ("S6","Within-cohort Spearman correlations across primary patients. Each unique gene pair is listed once."),
        ("S7–S8","TCGA 450K and CPTAC-3 EPIC beta values are in [0,1]. Original-panel RNA uses log2(TPM+1). Missing values are omitted from marker-level analyses."),
        ("S8","Direction compares the side of 0.5 of the two cohort point estimates. Median difference is CPTAC-3 minus TCGA in assay units. Cohort and platform vary together."),
        ("S9","Initial TCGA fit using the published code and tuning grid. 10,000 bootstrap replicates, original benchmark draw order."),
    ]
    with pd.ExcelWriter(path,engine="openpyxl") as writer:
        pd.DataFrame(notes,columns=["Table","How to read"]).to_excel(writer,sheet_name="Guide",index=False)
        for title,frame in frames.items():
            frame.to_excel(writer,sheet_name=title,index=False)
        for ws in writer.book.worksheets:
            ws.freeze_panes="B2"
            ws.auto_filter.ref=ws.dimensions
            ws.sheet_view.showGridLines=False
            for cell in ws[1]:
                cell.font=Font(name="Calibri",bold=True,color="FFFFFF")
                cell.fill=PatternFill("solid",fgColor="235366")
                cell.alignment=Alignment(vertical="center",wrap_text=True)
            ws.row_dimensions[1].height=33
            for j,col in enumerate(ws.columns,1):
                width=max(len(str(c.value or "")) for c in col)
                ws.column_dimensions[get_column_letter(j)].width=min(52,max(13,width+2))
                for cell in list(col)[1:]:
                    if isinstance(cell.value,float):
                        cell.number_format="0.000000"
                    if cell.row%2==0:
                        cell.fill=PatternFill("solid",fgColor="F2F6F7")
            if ws.title=="Guide":
                ws.column_dimensions["B"].width=96
                for row in list(ws.rows)[1:]:
                    row[1].alignment=Alignment(wrap_text=True,vertical="center")
                    ws.row_dimensions[row[0].row].height=40


if __name__=="__main__":
    write_book(Path(sys.argv[1]) if len(sys.argv)>1 else OUT/"LUAD_Supplement.xlsx")
