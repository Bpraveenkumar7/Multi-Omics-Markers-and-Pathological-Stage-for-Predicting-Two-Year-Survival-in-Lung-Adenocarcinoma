"""Plot local refits, fixed-model transfer and the score distributions in Figure 3."""
import zipfile
import numpy as np
import pandas as pd
from scipy.stats import mannwhitneyu
from matplotlib.lines import Line2D
from figures import plt, save, INK, RUST, TEAL
from analyze import ROOT, OUT, GROWTH, LUNG, COHORTS, read_measurements


def main():
    with zipfile.ZipFile(ROOT/"LUAD_benchmark_audit.zip") as archive:
        repeats = pd.read_csv(archive.open("repeat_auc.csv"))
    original = pd.read_csv(OUT/"external85_refit.csv").set_index("model")
    ext = pd.read_excel(OUT/"LUAD_Supplement.xlsx", sheet_name="S2 External models")
    ext = ext.loc[ext.cohort.eq("CPTAC-3 primary")].set_index("model")
    rows = []
    for name,label in [("Molecular RF","Class-weighted forest"),("Downsampled molecular RF","Downsampled forest")]:
        s=repeats[name]
        rows.append((label,s.mean(),s.min(),s.max(),True))
    for name,label in [("Molecular RF","Raw 32-marker forest"),("Molecular ridge","Raw 32-marker ridge"),
                       ("Stage + molecular ridge","Stage + raw ridge")]:
        r=original.loc[name]
        rows.append((label,r.estimate,r.lower_95,r.upper_95,False))
    for name,label in [("Original 32, ranked, molecular only","Ranked 32-marker ridge"),
                       ("Ten-gene RNA only","Ten-gene RNA"),("Major stage","Major stage")]:
        r=ext.loc[name]
        rows.append((label,r.auc,r.auc_low,r.auc_high,False))
    data,_=read_measurements()
    u=data[GROWTH].to_numpy()[:,:,None]
    v=data[LUNG].to_numpy()[:,None,:]
    data["rna_score"]=((u>v)+.5*(u==v)).mean(axis=(1,2))
    fig,(a,b)=plt.subplots(1,2,figsize=(10,4.2),gridspec_kw={"width_ratios":[1.05,1]})
    a.axvline(.5,ls=":",color="#8899a2",lw=1)
    a.axvline(.815,ls="--",color="#8899a2",lw=1)
    a.axhline(5.5,color="#d5dfe3",lw=.8)
    for i,(_,x,lo,hi,local) in enumerate(rows):
        y=len(rows)-1-i
        a.plot([lo,hi],[y,y],color=RUST if local else TEAL,lw=1.5)
        a.plot(x,y,"o" if local else "s",ms=4.8,color=RUST if local else TEAL)
    a.set(yticks=range(len(rows)),yticklabels=[r[0] for r in rows[::-1]],ylim=(-.7,7.9),xlim=(.19,.94),xlabel="ROC AUC",xticks=[.2,.4,.6,.8])
    a.tick_params(axis="y",length=0,labelsize=8.3)
    a.spines["left"].set_visible(False)
    rng=np.random.default_rng(20261125)
    for i,c in enumerate(COHORTS):
        frame=data[data.cohort.eq(c)]
        values=[frame.loc[frame.death.eq(k),"rna_score"].to_numpy() for k in (0,1)]
        for k,(vls,col) in enumerate(zip(values,[TEAL,RUST])):
            pos=i+(k-.5)*.34
            b.scatter(pos+rng.uniform(-.075,.075,len(vls)),vls,s=3.6,alpha=.35,color=col,edgecolors="none")
            b.boxplot(vls,positions=[pos],widths=.23,showfliers=False,manage_ticks=False,
                      boxprops={"color":col},medianprops={"color":INK,"linewidth":1.4},
                      whiskerprops={"color":col},capprops={"color":col})
        p=mannwhitneyu(*values,alternative="two-sided",method="asymptotic").pvalue
        b.text(i,1.065,"p < 0.001" if p<.001 else f"p = {p:.3f}",ha="center",fontsize=7.3)
    b.set(ylim=(-.025,1.15),xlim=(-.5,3.5),yticks=[0,.25,.5,.75,1],xticks=range(4),xticklabels=COHORTS,ylabel="Fraction of proliferation–differentiation pairs")
    b.tick_params(axis="x",labelsize=8.2)
    a.set_title("A   Two-year mortality in CPTAC-3",loc="left",weight="bold",fontsize=10)
    b.set_title("B   Ten-gene score by outcome",loc="left",weight="bold",fontsize=10)
    fig.legend(handles=[Line2D([],[],marker="o",ls="",color=TEAL,label="Survived to two years"),
                        Line2D([],[],marker="o",ls="",color=RUST,label="Died before two years")],
               loc="lower right",bbox_to_anchor=(.99,.015),frameon=False,ncol=2,fontsize=8)
    fig.subplots_adjust(left=.18,right=.995,bottom=.20,top=.88,wspace=.3)
    save(fig,"Figure3_benchmark")


if __name__=="__main__":
    main()
