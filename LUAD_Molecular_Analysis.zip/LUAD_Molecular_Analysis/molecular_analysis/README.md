# Molecular measurements and two-year mortality in lung adenocarcinoma

This directory reproduces the original TCGA-to-CPTAC-3 transfer result and reports post hoc molecular analyses for the revised manuscript. It uses the measured data bundled in the two original study archives in this repository. The four primary cohorts contain 873 unique patients, including 188 deaths before day 730. CPTAC-3 excludes known non-cancer deaths. Patients censored before day 730 without a recorded death have unknown two-year status and are outside these analyses.

## Main findings

- Refitting the 300-tree forest and selecting its feature-sampling parameter in TCGA reproduced the archived patient scores. On 85 CPTAC-3 patients (10 deaths), ROC AUC was **0.4613** (95% CI **0.2413–0.6900**) and average precision was **0.2589**. In the same patients the raw molecular ridge model yielded 0.4507 and stage alone 0.7880.
- Each of the five proliferation genes tended to be higher in early deaths and each of the five lung-differentiation genes tended to be lower in all four cohorts. Of 40 gene-by-cohort contrasts, 29 had Benjamini–Hochberg adjusted p < 0.05. The signs also persisted when comparisons were restricted to patient pairs with the same recorded stage.
- Ten of 20 CpGs and four of 12 transcripts in the original panel had point estimates on opposite sides of 0.50 between TCGA and CPTAC-3. The largest absolute median beta shift was at cg10441898 (+0.179 in CPTAC-3). Probe distributions reflect both cohort and platform. The sign counts include imprecise estimates and do not constitute a test of interaction.
- The ten-gene score increased AUC beyond the clinical model in GSE72094 by 0.0229 (paired 95% CI 0.0076–0.0402). The corresponding changes were +0.0120 in primary CPTAC-3 and −0.0012 in GSE31210. Consistent expression directions do not establish a causal mechanism or universal incremental prediction.

## Reproduce the analysis

Use Python 3.12. From the root of a local clone of this branch, run the following commands. No network access is needed after the dependencies are installed.

```sh
python -m pip install -r molecular_analysis/requirements.txt
python molecular_analysis/analyze.py
python molecular_analysis/figures.py
python molecular_analysis/supplement.py
python molecular_analysis/benchmark_figure.py
```

The first command installs the versions used in the original benchmark together with the plotting library. The analysis reads the embedded dataset in `LUAD_external_transfer.ipynb`, verifies the SHA-256 of its payload, checks patient uniqueness and event counts, and reads original benchmark inputs from `LUAD_benchmark_audit.zip`. It uses the repository's original `LUAD_benchmark_audit/model_eval.py` to refit four models. It compares all external patient scores to their archived counterparts and checks all 85-patient bootstrap intervals against the original benchmark. Those intervals use 10,000 outcome-stratified patient draws and the original draw ordering. The stage-ordering interval in the later external-transfer notebook uses the same estimand and a different batching of the random draws.

The manuscript supplement command executes the original follow-up notebook's code cells in order in a temporary working directory, recomputes its clinical model metrics, and writes `results/LUAD_Supplement.xlsx`. The workbook's Guide describes all nine tables. Tables S1–S4 reconstruct the previous benchmark outputs or definitions. Tables S5–S9 cover the new analyses and external refit. Both original notebooks remain the source for the pre-existing model designs. The archived local CV comparisons were summarized from their 20 original repetitions.

## Molecular analysis files

| Output under `results/` | Contents |
| --- | --- |
| `ten_gene_effects.csv` | S5. Forty outcome contrasts. Counts, native-scale outcome quartiles, higher-expression AUCs, pointwise intervals, raw and adjusted p-values, and same-stage concordance. |
| `ten_gene_correlations.csv` | S6. All 45 unique gene–gene Spearman correlations in each of four cohorts. |
| `original_panel_effects.csv` | S7. Within-cohort distributions and mortality contrasts for the 20 CpGs and 12 RNA measurements in TCGA and primary CPTAC-3. |
| `original_panel_shifts.csv` | S8. Observed counts and quartiles by cohort, median differences in native units, and directions of marginal outcome association. |
| `external85_refit.csv`, `refit_parameters.json` | S9. Reproduced external AUCs, 95% intervals, average precision and chosen TCGA hyperparameters. |
| `Figure3_benchmark`, `Figure7_gene_effects`, `Figure8_CpG_transfer` | Print-ready figures in vector PDF and 420-dpi PNG formats. |
| `LUAD_Supplement.xlsx` | Tables S1–S9, with a guide to the results. |

For observed measurements, higher-value AUC is the probability that a death has a higher measurement than a survivor, with ties receiving half weight. Single-gene effects use two-sided asymptotic Mann–Whitney tests, with continuity and tie corrections, and 5,000 outcome-stratified bootstrap replicates per marker. Missing measurements are omitted. The Benjamini–Hochberg families comprise 40 ten-gene contrasts and, separately, 64 original-panel contrasts. Within-stage concordance weights eligible same-stage death–survivor pairs equally and excludes missing stage. The original clinical score analysis uses the training median to fill missing stage.

Before comparing the two score panels, note that they contain different genes. The ten-gene follow-up score was examined after the initial CPTAC-3 transfer results were known. The two GEO cohorts entered only at external scoring. These molecular analyses did not alter the feature definitions, score weights, prediction rules or outcome labels.

[Original feature-selection study and supplementary material](https://doi.org/10.3390/ijms25073661)
